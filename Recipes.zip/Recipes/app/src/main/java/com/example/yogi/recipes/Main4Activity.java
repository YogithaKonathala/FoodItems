package com.example.yogi.recipes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {
    String ingred;
    String prepare;
    int pos;
    TextView t1,t2;
    String[] data;
    String[] datas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        t1=findViewById(R.id.texxt);
        t2=findViewById(R.id.prep);
         data=getResources().getStringArray(R.array.Ingredients);
         datas=getResources().getStringArray(R.array.preparation);
        pos=getIntent().getIntExtra("pos",0);
        t1.setText(data[pos]);
        t2.setText(datas[pos]);
         }
}
