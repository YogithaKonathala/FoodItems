package com.example.yogi.recipes;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VersionHolder> {
    MainActivity mainActivity;
    String[] recipes;
    String[] description;
    int[] image;

    public VersionAdapter(MainActivity mainActivity1, int[] images, String[] names, String[] descrip) {
        recipes=names;
        description=descrip;
        image=images;
        mainActivity=mainActivity1;
    }


    @NonNull
    @Override

    public VersionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mainActivity).inflate(R.layout.row,parent,false);
        VersionHolder versionHolder=new VersionHolder(view);
        return versionHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final VersionHolder holder, final int position) {
        holder.tv1.setText(recipes[position]);
        holder.tv2.setText(description[position]);
        holder.img.setImageResource(image[position]);
        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(mainActivity,Main4Activity.class);
                int pos=holder.getAdapterPosition();
                i.putExtra("pos",pos);
                mainActivity.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return recipes.length;
    }

    public class VersionHolder extends RecyclerView.ViewHolder {
        TextView tv1,tv2;
        ImageView img;
        public VersionHolder(View itemView) {
            super(itemView);
            tv1=itemView.findViewById(R.id.text1);
            tv2=itemView.findViewById(R.id.textdec1);
            img=itemView.findViewById(R.id.image1);
        }
    }
}
