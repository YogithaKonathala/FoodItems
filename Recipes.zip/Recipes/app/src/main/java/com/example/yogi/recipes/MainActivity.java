package com.example.yogi.recipes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    VersionAdapter versionAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycle);
        int[] images={R.drawable.burger,R.drawable.chickenpopcorn,R.drawable.chocoroll,R.drawable.icecreamsandwich,R.drawable.pavbaj,
                R.drawable.pizza,R.drawable.puff,R.drawable.samosa,R.drawable.strawberry,R.drawable.burger};
        String[] names={"Burger","Chickenpopcorn","Chocoroll","Icecreamsandwich","Pavbaj","pizza","Puff","Samosa","Strawberry","Burger"};
        String[] descrip= {"A hamburger, beefburger or burger is a sandwich consisting of one or more cooked patties of ground meat, usually beef, placed inside a sliced bread roll or bun.",
                "Popcorn Chicken is a KFC product consisting of small, pieces of chicken and popcorn that have been breaded and fried.",
                " This Chocolate Swiss Roll is a rich, chocolaty and decadent dessert, a rewarding treat for chocolate lovers",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!",
                "Pav bhaji is a fast food dish from India, consisting of a thick vegetable curry, fried and served with a soft bread roll. 6",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!",
                "Homemade Ice Cream Sandwiches? Yes, please! Make your own flavor combinations with this easy Ice Cream Sandwich recipe!"};
        versionAdapter=new VersionAdapter(this,images,names,descrip);
        recyclerView.setAdapter(versionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
